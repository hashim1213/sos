"use client"

import { motion as framerMotion } from "framer-motion"

export const motion = framerMotion
